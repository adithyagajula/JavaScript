function replaceText(){
document.getElementById("para")
.innerHTML="<b>Hello,Good Afternoon</b>";
}
