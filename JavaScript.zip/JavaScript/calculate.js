function sum(){
    var a = document.getElementById("num1").value;
    
    var b = document.getElementById("num2").value;
    if(a>=0&&b>=0)
    {
    alert(parseInt(a)+parseInt(b));
    }
    else{
        alert("enter positive numbers :");
    }
}
function subraction(){
    var a = document.getElementById("num1").value;
    
    var b = document.getElementById("num2").value;
    if(a>=0&&b>=0)
    {
    alert(parseInt(a)-parseInt(b));
    }
    else{
        alert("enter positive numbers :");
    }

}
function multi(){
    var a = document.getElementById("num1").value;
    
    var b = document.getElementById("num2").value;
    if(a>=0&&b>=0)
    {
    alert(parseInt(a)*parseInt(b));
    }
    else{
        alert("enter positive numbers :");
    }


}
function divi(){
    var a = document.getElementById("num1").value;
    
    var b = document.getElementById("num2").value;
    if(a>=0&&b>=0)
    {
    alert(parseInt(a)/parseInt(b));
    }
    else{
        alert("enter positive numbers :");
    }

}