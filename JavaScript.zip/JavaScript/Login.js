function validate(){
    var user = document.getElementById("username").value;
    var regEx = /[a-z A-Z]{4,8}$/;
    if(regEx.test(user)){
        alert("valid");
    }
    else{
        alert("Invalid");
    }
}
function validate2(){
    var mobile = document.getElementById("mobile").value;
    var mregEx = /(91|0)?[6-9][0-9]{9}$/;
    if(mregEx.test(mobile)){
        alert("valid");
    }
    else{
        alert("Invalid");
    }
}