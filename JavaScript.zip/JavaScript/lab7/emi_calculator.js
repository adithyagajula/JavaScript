function compute(){
    var amount = document.getElementById("Amount").value;
    var years = document.getElementById("years").value;
    var interest = document.getElementById("interest").value;
    p=parseInt(amount);
    t=parseInt(years);
    r=parseInt(interest);
    iamt=(p*t*r)/100;
    tamt=p+iamt;
    mamt=(tamt)/(t*12);
   
    if(amount>1500000){
        
        alert("Invalid amount");
    }
    else if(t<7||t>15){
        alert("invalid");
    }
    else{
        document.getElementById("amount2").value=mamt;
        document.getElementById("amount3").value=tamt;
        document.getElementById("amount4").value=mamt*t*12-p;
    }
}